### Curso Backend Nodejs
>Alumno: Jorge Luis Repossi

>Comisión: 30995 
###


[![](https://img.shields.io/badge/LinkedIn-jorge-repossi)](https://www.linkedin.com/in/jorgerepossi/)
[![](https://img.shields.io/badge/Behance-Verbo-Studio)](https://www.behance.net/verbostudio)
[![](https://img.shields.io/badge/Gmail-jorgerepossi1980%40gmail.com-red)](mailto:jorgerepossi1980010@gmail.com)


### Jorge Luis Repossi



- [@jorgerepossi](https://github.com/jorgerepossi)

