
/*
Entrega 03 - Clase 06
Alumno: Jo Repossi
Backend: NodeJS
Comisión 30995
Profesor: Diego Jofre
Fecha: Martes 7 Junio 2022
**/

require( 'dotenv' ).config();
const Server = require( './server' )

const server = new Server()
server.listen()